package com.ohgonglee.agent

object NativeLlama {
    init { System.loadLibrary("ohgonglee_native") }
    external fun nativeLoadModel(path: String, contextSize: Int): String
    external fun nativeGenerate(prompt: String, maxTokens: Int): String
    external fun nativeRelease()
}
