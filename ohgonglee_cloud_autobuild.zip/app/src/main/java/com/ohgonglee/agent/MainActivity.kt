package com.ohgonglee.agent

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OhgongleeApp() }
    }
}

private data class ChatMessage(val text: String, val fromUser: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun OhgongleeApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("ohgonglee", 0) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
    var modelPath by remember { mutableStateOf(prefs.getString("model_path", null)) }
    var showSettings by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var engineReady by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("엔진 대기 중") }
    val scope = rememberCoroutineScope()
    val messages = remember { mutableStateListOf(ChatMessage("안녕하세요! ohgonglee 로컬 AI입니다. GGUF 모델을 선택한 뒤 엔진을 연결해 주세요.", false)) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            val name = "selected-model.gguf"
            val dest = File(context.filesDir, name)
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                dest.outputStream().use { output -> inputStream.copyTo(output) }
            }
            modelPath = dest.absolutePath
            prefs.edit().putString("model_path", modelPath).apply()
            messages.add(ChatMessage("모델 파일 선택됨: ${dest.name} (${dest.length() / (1024 * 1024)} MB). 모델 로드를 눌러 주세요.", false))
            engineReady = false
        }
    }

    MaterialTheme(colorScheme = if (dark) darkColorScheme(
        primary = Color(0xFFB7A2FF), background = Color(0xFF101116),
        surface = Color(0xFF191B24), surfaceVariant = Color(0xFF252735)
    ) else lightColorScheme(
        primary = Color(0xFF6550B8), background = Color(0xFFF7F7FB),
        surface = Color.White, surfaceVariant = Color(0xFFECECF3)
    )) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("ohgonglee", fontWeight = FontWeight.Bold)
                            Text(if (engineReady) "LOCAL ENGINE READY" else status, style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    },
                    actions = {
                        IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "설정") }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
                )
            },
            bottomBar = {
                Row(
                    Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.weight(1f), placeholder = { Text("메시지를 입력하세요") },
                        maxLines = 4, shape = RoundedCornerShape(24.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    FilledIconButton(
                        onClick = {
                            val text = input.trim()
                            if (text.isNotEmpty()) {
                                messages.add(ChatMessage(text, true))
                                input = ""
                                if (!engineReady) {
                                    messages.add(ChatMessage("먼저 GGUF 모델을 선택하고 '모델 로드'를 눌러 주세요.", false))
                                } else if (!busy) {
                                    busy = true
                                    status = "생성 중..."
                                    scope.launch {
                                        val answer = withContext(Dispatchers.IO) {
                                            try {
                                                NativeLlama.nativeGenerate("### Instruction:\n$text\n\n### Response:\n", 256)
                                            } catch (e: Throwable) {
                                                "생성 오류: ${e.message}"
                                            }
                                        }
                                        messages.add(ChatMessage(answer, false))
                                        busy = false
                                        status = "LOCAL ENGINE READY"
                                    }
                                }
                            }
                        },
                        enabled = input.isNotBlank() && !busy
                    ) { Icon(Icons.Default.Send, "전송") }
                }
            },
            floatingActionButton = {
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (modelPath != null) {
                        ExtendedFloatingActionButton(
                            onClick = {
                                val path = modelPath!!
                                status = "모델 로딩 중..."
                                scope.launch {
                                    val result = withContext(Dispatchers.IO) {
                                        try { NativeLlama.nativeLoadModel(path, 2048) }
                                        catch (e: Throwable) { "엔진 오류: ${e.message}" }
                                    }
                                    engineReady = result == "OK"
                                    status = if (engineReady) "LOCAL ENGINE READY" else result
                                    messages.add(ChatMessage(
                                        if (engineReady) "모델이 로드되었습니다. 이제 로컬 대화가 가능합니다." else result,
                                        false
                                    ))
                                }
                            },
                            icon = { Icon(Icons.Default.PlayArrow, null) },
                            text = { Text("모델 로드") }
                        )
                    }
                    ExtendedFloatingActionButton(
                        onClick = { picker.launch(arrayOf("application/octet-stream", "*/*")) },
                        icon = { Icon(Icons.Default.FolderOpen, null) },
                        text = { Text("GGUF 모델 선택") }
                    )
                }
            },
            floatingActionButtonPosition = FabPosition.End
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("나만의 로컬 AI", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text("대화와 모델 파일은 이 기기 안에서 관리하도록 설계되었습니다.", style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.height(8.dp))
                            Text("선택 모델: ${modelPath?.substringAfterLast('/') ?: "없음"}", style = MaterialTheme.typography.labelMedium)
                            Text("엔진 상태: $status", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                items(messages) { msg ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start) {
                        Surface(
                            color = if (msg.fromUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.widthIn(max = 320.dp)
                        ) {
                            Text(msg.text, Modifier.padding(horizontal = 14.dp, vertical = 11.dp),
                                color = if (msg.fromUser) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            }
        }

        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("설정") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("다크 모드", fontWeight = FontWeight.SemiBold)
                                Text("화이트 모드와 언제든 전환할 수 있어요.", style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(checked = dark, onCheckedChange = {
                                dark = it
                                prefs.edit().putBoolean("dark", it).apply()
                            })
                        }
                        HorizontalDivider()
                        Text("모델 경로", style = MaterialTheme.typography.labelLarge)
                        Text(modelPath ?: "선택된 모델 없음", style = MaterialTheme.typography.bodySmall)
                        Text("엔진: ${if (engineReady) "실행 중" else status}", style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = { TextButton(onClick = { showSettings = false }) { Text("닫기") } }
            )
        }
    }
}
