#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include <algorithm>
#include "llama.h"

static std::mutex g_mutex;
static llama_model* g_model = nullptr;
static llama_context* g_ctx = nullptr;
static llama_sampler* g_sampler = nullptr;

static void release_locked() {
    if (g_sampler) { llama_sampler_free(g_sampler); g_sampler = nullptr; }
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_ohgonglee_agent_NativeLlama_nativeLoadModel(JNIEnv* env, jobject, jstring jpath, jint contextSize) {
    const char* chars = env->GetStringUTFChars(jpath, nullptr);
    std::string path(chars ? chars : "");
    if (chars) env->ReleaseStringUTFChars(jpath, chars);
    std::lock_guard<std::mutex> lock(g_mutex);
    release_locked();

    llama_model_params mp = llama_model_default_params();
    g_model = llama_model_load_from_file(path.c_str(), mp);
    if (!g_model) return env->NewStringUTF("모델 로드 실패: GGUF 파일을 확인해 주세요.");

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = (uint32_t)std::max(512, std::min(4096, (int)contextSize));
    cp.n_batch = 512;
    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) {
        release_locked();
        return env->NewStringUTF("컨텍스트 생성 실패: 메모리가 부족할 수 있습니다.");
    }
    g_sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(g_sampler, llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_dist(1234));
    return env->NewStringUTF("OK");
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_ohgonglee_agent_NativeLlama_nativeGenerate(JNIEnv* env, jobject, jstring jprompt, jint maxTokens) {
    const char* chars = env->GetStringUTFChars(jprompt, nullptr);
    std::string prompt(chars ? chars : "");
    if (chars) env->ReleaseStringUTFChars(jprompt, chars);
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_model || !g_ctx || !g_sampler) return env->NewStringUTF("모델이 로드되지 않았습니다.");

    const llama_vocab* vocab = llama_model_get_vocab(g_model);
    std::vector<llama_token> tokens(prompt.size() + 64);
    int n = llama_tokenize(vocab, prompt.c_str(), (int)prompt.size(), tokens.data(),
                           (int)tokens.size(), true, true);
    if (n < 0) {
        tokens.resize((size_t)-n);
        n = llama_tokenize(vocab, prompt.c_str(), (int)prompt.size(), tokens.data(),
                           (int)tokens.size(), true, true);
    }
    if (n <= 0) return env->NewStringUTF("프롬프트 토큰화 실패");
    tokens.resize((size_t)n);

    llama_memory_clear(llama_get_memory(g_ctx), true);
    llama_sampler_reset(g_sampler);
    llama_batch batch = llama_batch_get_one(tokens.data(), (int)tokens.size());
    if (llama_decode(g_ctx, batch) != 0) return env->NewStringUTF("프롬프트 처리 실패");

    std::string output;
    int limit = std::max(1, std::min(512, (int)maxTokens));
    for (int i = 0; i < limit; ++i) {
        llama_token token = llama_sampler_sample(g_sampler, g_ctx, -1);
        if (llama_vocab_is_eog(vocab, token)) break;
        llama_sampler_accept(g_sampler, token);
        char piece[4096];
        int count = llama_token_to_piece(vocab, token, piece, sizeof(piece), 0, true);
        if (count > 0) output.append(piece, (size_t)count);
        batch = llama_batch_get_one(&token, 1);
        if (llama_decode(g_ctx, batch) != 0) break;
    }
    return env->NewStringUTF(output.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_ohgonglee_agent_NativeLlama_nativeRelease(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    release_locked();
}
