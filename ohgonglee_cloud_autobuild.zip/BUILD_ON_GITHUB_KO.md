# ohgonglee APK 자동 빌드 (휴대폰에서도 가능)

이 프로젝트에는 GitHub Actions 자동 빌드 워크플로가 포함되어 있습니다.
Android SDK, NDK, CMake, Gradle을 클라우드 러너에 설치하고 C++ 네이티브 라이브러리와 APK를 한 번에 빌드합니다.

## 처음 한 번만 필요한 설정
1. GitHub 계정으로 새 저장소(repository)를 만듭니다.
2. 이 ZIP의 압축을 풀고 **압축 안의 파일과 폴더 전체**를 저장소 최상위에 업로드합니다.
3. 저장소의 `Actions` 탭을 엽니다.
4. `ohgonglee APK Build`를 선택합니다.
5. `Run workflow`를 누릅니다.

이후 `main` 브랜치에 변경사항을 올리면 자동으로 다시 빌드됩니다.

## APK 받기
빌드가 성공하면 해당 실행(run) 페이지의 `Artifacts`에서 `ohgonglee-debug-apk`를 내려받습니다. Artifact ZIP을 풀면 APK가 있습니다.

## 중요한 점
- 이 워크플로는 APK를 자동 **빌드**하지만, 소스의 컴파일 오류를 AI가 자동으로 고쳐준다고 보장하지 않습니다.
- 현재 C++ JNI 코드는 실제 Android NDK에서 검증되지 않았습니다. 첫 실행에서 upstream llama.cpp API 차이 등으로 빌드가 실패할 수 있습니다. 실패하면 `ohgonglee-build-logs`를 확인해야 합니다.
- 성공한 APK도 실제 Galaxy S25에서 모델 로딩과 메모리 사용을 시험해야 합니다.
- Qwen GGUF 모델 파일은 ZIP에 포함하지 않았습니다. 앱 안에서 별도로 선택해야 합니다.
- Debug APK는 테스트용입니다. 배포용 서명 APK와는 다릅니다.
