#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -d llama.cpp/.git ]; then
  git clone --depth 1 https://github.com/ggml-org/llama.cpp.git llama.cpp
else
  echo "llama.cpp source already exists; keeping it unchanged."
fi
echo "llama.cpp source ready."
