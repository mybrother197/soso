# ohgonglee — Android local LLM integration

Galaxy S25 (ARM64) Android project with Compose UI, persisted dark/light theme,
GGUF picker, and a JNI bridge to llama.cpp.

## Included
- Local GGUF model file picker and app-private copy
- Native JNI functions for model load, text generation, and release
- UI actions to load a model and generate a response off the main thread
- Android native ABI configured for `arm64-v8a`

## Prepare source
Run `./setup_native.sh` from this project root to fetch the upstream llama.cpp source into `llama.cpp/`.

## Build requirements
- Android Studio with JDK 17
- Android SDK Platform 35
- Android NDK `27.2.12479018`
- CMake `3.22.1`

Then build `app:assembleDebug`. The Gradle build invokes CMake and packages the JNI library into the APK.

## Build status — important
The current execution environment has CMake and Ninja but no Android SDK or NDK. Therefore an Android `.so` or APK could not be compiled or device-tested here. This archive contains native integration source and build configuration, **not a verified compiled native binary or finished APK**.

## Limitations
- CPU backend only; no GPU/NPU acceleration configured.
- Basic instruction/response prompt; model-specific chat templates are not yet applied.
- Generation is non-streaming and capped at 256 tokens in the current UI.
- Chat history is held in memory only; durable chat storage, cancellation, and robust error recovery remain to be implemented.
- Start with a small quantized GGUF to reduce memory pressure.
- Official build guidance: https://github.com/ggml-org/llama.cpp/blob/master/docs/build.md
